import cv2
import os
import numpy as np
import requests
import json
subjects = ["","1_Name1","2_Name2"]



def detect_face(frame):


    faceCascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    eye_cascade = cv2.CascadeClassifier('haarcascade_eye.xml')
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)


    faces = faceCascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(30, 30),
        flags=cv2.CASCADE_SCALE_IMAGE
    )
    for (x, y, w, h) in faces:
        roi_gray = gray[y:y+h, x:x+w]
        roi_color = frame[y:y+h, x:x+w]
        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
        eyes = eye_cascade.detectMultiScale(roi_gray)
        for (ex,ey,ew,eh) in eyes:
            cv2.rectangle(roi_color,(ex,ey),(ex+ew,ey+eh),(0,255,0),2)

    if (len(faces) == 0):
        return None, None
        
    if (len(eyes) == 0):
        return None, None
		
    (x, y, w, h) = faces[0]
	
	
    return roi_gray, faces[0]



def prepare_training_data(data_folder_path):
    
    
    dirs = os.listdir(data_folder_path)
    
    #list to hold all subject faces
    faces = []
    #list to hold labels for all subjects
    labels = []
    
    #let's go through each directory and read images within it
    for dir_name in dirs:
        
        
        if not dir_name.startswith("s"):
            continue;
            
        
        label = int(dir_name.replace("s", ""))
        
        
        subject_dir_path = data_folder_path + "/" + dir_name
        
        #get the images names that are inside the given subject directory
        subject_images_names = os.listdir(subject_dir_path)
        
       
        for image_name in subject_images_names:
            
            #ignore system files like .DS_Store
            if image_name.startswith("."):
                continue;
            
            #build image path
            #sample image path = training-data/s1/1.pgm
            image_path = subject_dir_path + "/" + image_name

            #read image
            image = cv2.imread(image_path)
            
            #display an image window to show the image 
            cv2.imshow("Training on image...", cv2.resize(image, (400, 500)))
            cv2.waitKey(100)
            
            #detect face
            face, rect = detect_face(image)
            
            if face is not None:
                #add face to list of faces
                faces.append(face)
                #add label for this face
                labels.append(label)
            else:
                print(image_name)
      
            
               
             
            
    cv2.destroyAllWindows()
    cv2.waitKey(1)
    cv2.destroyAllWindows()

    return faces, labels

    
    dirs = os.listdir(data_folder_path)
    
    faces = []

    labels = []
    
    for dir_name in dirs:
        
        if not dir_name.startswith("s"):
            continue;
            
        label = int(dir_name.replace("s", ""))

        subject_dir_path = data_folder_path + "/" + dir_name
        
        subject_images_names = os.listdir(subject_dir_path)

        for image_name in subject_images_names:
            
            if image_name.startswith("."):
                continue;
            
            image_path = subject_dir_path + "/" + image_name

            #read image
            image = cv2.imread(image_path)
            
            #display an image window to show the image 
            #cv2.imshow("Training on image...", cv2.resize(image, (400, 500)))-------------------------------------------------HERE---------------------------------------         
            #cv2.waitKey(100)
            
            #detect face
            face, rect = detect_face(image)
            
            
            if face is not None:
                #add face to list of faces
                faces.append(face)
                #add label for this face
                labels.append(label)
            else:
                print(image_name)
            
    cv2.destroyAllWindows()
    cv2.waitKey(1)
    cv2.destroyAllWindows()
    
    return faces, labels



def draw_rectangle(img, rect):
    (x, y, w, h) = rect
    cv2.rectangle(img, (x, y), (x+w, y+h), (0, 255, 0), 2)
    
#function to draw text on give image starting from
#passed (x, y) coordinates. 
def draw_text(img, text, x, y):
    cv2.putText(img, text, (x, y), cv2.FONT_HERSHEY_PLAIN, 1.5, (0, 255, 0), 2)


def predict(test_img):
    #make a copy of the image as we don't want to chang original image
    img = test_img.copy()
    #detect face from the image
    face, rect = detect_face(img)

    label, confidence = face_recognizer.predict(face)
    label_text = subjects[label]
    draw_rectangle(img, rect)
    cv2.putText(img, label_text, (rect[0], rect[1]-5), cv2.FONT_HERSHEY_PLAIN, 1.5, (0, 255, 0), 2)

    
    return img


print("Preparing data...")
faces, labels = prepare_training_data("training-data")
print("Data prepared")

#print total faces and labels
print("Total faces: ", len(faces))
print("Total labels: ", len(labels))


face_recognizer = cv2.cv2.face.LBPHFaceRecognizer_create()


face_recognizer.train(faces, np.array(labels))


last_label = 0;
print("Predicting images...")
vc = cv2.VideoCapture(0)
frameWidth = int(vc.get(cv2.CAP_PROP_FRAME_WIDTH))
frameHeight = int(vc.get(cv2.CAP_PROP_FRAME_HEIGHT))
if vc.isOpened(): # try to get the first frame
    rval, frame = vc.read()
else:
    rval = False

while rval:
    
    cv2.imshow("preview", frame)
    rval, frame = vc.read()
    key = cv2.waitKey(20)
    face, rect = detect_face(frame)
    if(face is not None):
        label, confidence = face_recognizer.predict(face)
        print(label)
        print(confidence)
        label_text = subjects[label]
        lbl_ID, lbl_TXT = label_text.split("_")
        #print(label)        
        if(confidence > 40):
            #print(label)
            #print(label_text)
            #print(confidence)
            cv2.putText(img = frame, text = lbl_TXT, org = (rect[0], rect[1]-5), fontFace = cv2.FONT_HERSHEY_DUPLEX, fontScale = 1, 
                color = (255, 0, 0))
            if((last_label != label) and (label is not None)):
                payload = {'ID': lbl_ID}
                last_label = label
                
            #draw_rectangle(face, rect)
            #draw_text(face, label_text, rect[0], rect[1]-5)
            cv2.imshow('preview', face)

    if key == 27: #exit on ESC
        break

cv2.destroyWindow("preview")
vc.release()