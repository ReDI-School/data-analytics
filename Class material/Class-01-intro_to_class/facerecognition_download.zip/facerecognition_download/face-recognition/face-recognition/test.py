import cv2
import sys
import numpy as np
import os

rok = ""
def prepare_training_data(data_folder_path):
    
    dirs = os.listdir(data_folder_path)
    if(len(dirs) == 0):
        os.makedirs(data_folder_path+"\s1")
        rok = data_folder_path + "\s1"
    else:
    
        index = 1
    
    
        for dir_name in dirs:
        
            if not dir_name.startswith("s"):
                continue;    
            else:
                index = index + 1;
        rok = data_folder_path + "\s{}" .format(index)
        os.makedirs(rok)
    return rok

loka = prepare_training_data("training-data")

faceCascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
eye_cascade = cv2.CascadeClassifier('haarcascade_eye.xml')
cv2.namedWindow("preview")
vc = cv2.VideoCapture(0)

if vc.isOpened(): # try to get the first frame
    rval, frame = vc.read()
else:
    rval = False
count = 0
while rval:
    cv2.imshow("preview", frame)
    vc.set(cv2.CAP_PROP_POS_MSEC,(count*5000))
    rval, frame = vc.read()
    key = cv2.waitKey(20)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    faces = faceCascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(30, 30),
        flags=cv2.CASCADE_SCALE_IMAGE
    )

    # Draw a rectangle around the faces
    if (len(faces) == 0):
        print("no face")
    else:
        for (x, y, w, h) in faces:
            roi_gray = gray[y:y+h, x:x+w]
            roi_color = frame[y:y+h, x:x+w]
            eyes = eye_cascade.detectMultiScale(roi_gray)
        cv2.imwrite( loka + "\\%d.jpg" % count, frame)
        count = count + 1
    # Display the resulting frame
    #cv2.imshow('preview', frame)
    
    if key == 27: #exit on ESC
        break

cv2.destroyWindow("preview")
vc.release()